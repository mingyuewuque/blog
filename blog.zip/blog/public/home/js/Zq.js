function $(id){
	if(/^#\w+/.test(id)){ //说明传进来的id是类似于"#content"
		id = id.substr(1);//要用document.getElementById方法就要去掉# 
		return document.getElementById(id);
	}
	else{
		return document.getElementsByTagName(id);
	}
}
$.hide=function(ele){
	ele.style.display = "none";
}
$.show=function(ele){
	ele.style.display = "block";
}
$.c = function(ele){
	return document.createElement(ele);
}
$.get=function(id,ele){
	return id.getElementsByTagName(ele);
}

$.set=function(defanltjson,json){
	var res={};
	for(var p in defanltjson){
		if(json&&json[p]){
			res[p]=json[p]
		}
		else{
			res[p]=defanltjson[p]
		}
	}
	return res;
}
$.random=function(min,max){
	return Math.floor(Math.random()*(max-min+1)+min);
}
