var express = require('express');
var router = express.Router();
var Objectid= require('Objectid');
const markdown = require('markdown').markdown;
var Mongoclient=require('mongodb').MongoClient;
const url='mongodb://localhost:27017/blog';

/* GET home page. */
router.get('/', function(req, res, next) {
    Mongoclient.connect(url,(err,db)=>{
        let articles=db.collection('articles');
        let lists=db.collection('lists');
        let oid=req.query.page;
        lists.find().toArray((err,res1)=>{
            if(err) throw err;
            articles.findOne({_id:Objectid(oid)},(err,res2)=>{
                if(err) throw err;
                let data={
                    res1:res1,
                    res2:res2
                };
                res.render('home/detail',{data:data});
            });
        });

    });
});

module.exports = router;
