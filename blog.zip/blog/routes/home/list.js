var express = require('express');
var router = express.Router();
var Mongoclient=require('mongodb').MongoClient;
const markdown = require('markdown').markdown;
const url='mongodb://localhost:27017/blog';

router.get('/', function(req, res, next) {
    Mongoclient.connect(url,(err,db)=>{
        let inow=req.query.cat;
        console.log(inow);
            let articles=db.collection('articles');
            articles.find({list:inow}).toArray((err,result)=>{
                console.log(result)
                res.render('home/list',{data:result})
            });


    });

});
module.exports = router;
