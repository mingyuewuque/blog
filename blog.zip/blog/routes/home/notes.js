var express = require('express');
var Objectid= require('Objectid');
var router = express.Router();
var Mongoclient=require('mongodb').MongoClient;
const url='mongodb://localhost:27017/blog'

/* GET home page. */
router.get('/', function(req, res, next) {
    Mongoclient.connect(url,(err,db)=>{
        let lists=db.collection('lists');
        lists.find().toArray((err,res1)=>{
            if(err) throw err;
            let articles=db.collection('articles');
            articles.find().toArray((err,res2)=>{
                if(err) throw err;
                articles.find().sort({count:-1}).toArray((err,res3)=>{
                    let notes=db.collection('notes');
                    notes.find().sort({date:-1}).limit(5).toArray((err,res4)=> {
                        let data = {
                            res1: res1,
                            res2: res2,
                            sorts: res3,
                            notes: res4
                        };
                        res.render('home/notes', {data: data});
                    });
                });

            });

        });
    });

});

router.get('/check', function(req, res, next) {

    Mongoclient.connect(url,(err,db)=>{
        let notes=db.collection('notes');
        notes.insert(req.query,(err,result)=>{
            notes.find().sort({date:-1}).limit(5).toArray((err,res1)=>{
                if(err) throw err;
                res.json(res1)
            })
        })

    });

});

router.get('/more', function(req, res, next) {
    Mongoclient.connect(url,(err,db)=>{
        let notes=db.collection('notes');

        notes.find().toArray((err,res3)=>{
            let total=res3.length;
            let nums=total%5==0?total/5:Math.ceil(total/5);
            notes.find().sort({date:-1}).limit(req.query.page*5).toArray((err,res2)=>{
                if(err) throw err;
                let data={
                    res2:res2,
                    nums:nums,
                };
                res.json(data)
            })
        });



    });

});

module.exports = router;
