var express = require('express');
var router = express.Router();
var Mongoclient=require('mongodb').MongoClient;
const markdown = require('markdown').markdown;
const url='mongodb://localhost:27017/blog';

router.get('/', function(req, res, next) {
    Mongoclient.connect(url,(err,db)=>{
        let articles=db.collection('articles');
        articles.find().toArray((err,result)=>{
            res.render('home/posts',{data:result})
        });
    });
});
module.exports = router;