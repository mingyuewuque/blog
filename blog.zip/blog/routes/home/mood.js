var express = require('express');
var router = express.Router();
var Mongoclient=require('mongodb').MongoClient;
const markdown = require('markdown').markdown;
const url='mongodb://localhost:27017/blog';

router.get('/', function(req, res, next) {
    Mongoclient.connect(url,(err,db)=>{
        let moods=db.collection('moods');
        moods.find().toArray((err,res1)=>{
            let lists=db.collection('lists');
            lists.find().toArray((err,res2)=>{
                let data={
                    moods:res1,
                    lists:res2
                };
                res.render('home/mood',{data:data});
            });


        });
    });
});


router.get('/test', function(req, res, next) {
    let data={
          txt:req.query.txt
    };
    Mongoclient.connect(url,(err,db)=>{
        let moods=db.collection('moods');
        moods.insert(data,(err,result)=>{
            if(err)throw err;
            res.send();
        });
    });
});
module.exports = router;
