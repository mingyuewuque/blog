var express = require('express');
var router = express.Router();
var Mongoclient=require('mongodb').MongoClient;
const url='mongodb://localhost:27017/blog'

/* GET home page. */
router.get('/', function(req, res, next) {
  if(req.session.islogoin){
    res.render('admin/index');
  }
  else{
    res.redirect('/admin/login')
  }
});

router.get('/login', function(req, res, next) {
  if(req.session.islogoin){
    res.redirect('/admin')
  }
  else{
    res.render('admin/login');
  }

});

router.post('/signin', function(req, res, next) {
  let user=req.body.username;
  let pass=req.body.password;

  Mongoclient.connect(url,(err,db)=>{
    let logins=db.collection('logins');
    logins.findOne({username:user,password:pass},(err,result)=>{
      if(err) throw err;
      if(result){
        req.session.islogoin=1;
        res.redirect('/admin');
      }
      else{
        res.redirect('/admin/login')
      }
    });
  });
});
router.get('/loginout', function(req, res, next) {
  req.session.destroy();
  res.redirect('/admin/login')
});
module.exports = router;
